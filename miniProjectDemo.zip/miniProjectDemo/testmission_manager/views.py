from django.shortcuts import render

# Create your views here.
from testmission_manager.models import TestMission as testMission
from testmission_manager.models import GenerateRecord as generateRecord
from testmission_manager.models import TestExamples as testExamples
from testmission_manager.models import GenerateResult as generateResult
from equipment_manager.models import EquipmentInfo as equipmentInfo
from testresult_manager.models import TestResult as testResult
from form_manager.models import Forms as forms
from form_manager.models import FormFields as formFields

from django.http import HttpResponse

from django.views.decorators.csrf import csrf_exempt

from controller.sqlController import SqlController
from controller.securitylib import createRandomChar
from controller.randGener import getRandomData
from publicViews.publicDBViews import getJsonAjax


import json
def generateData(obj):
    fields=obj["fields"]
    returnObj={}
    for field in fields:
        geneItem=fields[field]["item"]
        if geneItem=="nothing":
            defaultObj={}
            defaultObj["default"]=fields[field]["default"]
            defaultObj["geneItem"]="nothing"
            returnObj[field]=defaultObj
        else:
            getGene=getRandomData(geneItem)
            returnObj[field]=getGene
    return returnObj
'''新增mission数据和关联的missionresult数据'''
@csrf_exempt
def addMission(request):
    try:
        submitData=getJsonAjax(request,"submitData")
        submitData["randomKey"]=createRandomChar()
        submitData["state"]="beforeTesting"
        submitData["relatedUserkey"]="defaultuserkey"
        testMission.objects.create(**submitData)
        resultId=testMission.objects.get(**submitData).id
        resultData=({"equipmentUrl":submitData["equipmentUrl"],
                     "formUrl":submitData["formUrl"],
                     "formKey":submitData["formKey"],
                     "relatedMission":resultId,
                     "relatedUserkey":"defaultuserkey"
                     })
        testResult.objects.create(**resultData)
        return HttpResponse("存储完成")
    except Exception as e:
        return HttpResponse(str(e))
'''根据一定条件(如所属设备）获取关联的form列表'''
@csrf_exempt
def getMissions(request):
    try:
        returnList=[]
        sqlCtrl=SqlController(testMission)
        conditionData=getJsonAjax(request,"conditionData")
        if isinstance(conditionData,str):
            conditionData=json.loads(conditionData)
        missionResults=sqlCtrl.findData(conditionData,jsonDump=False)
        for result in missionResults:
            equipmentUrl=result["equipmentUrl"]
            formUrl=result["formUrl"]
            key=forms.objects.filter(relatedEquipment=equipmentUrl,formUrl=formUrl)
            if key:
                key=key[0].randomKey
            else:
                continue
            sqlCtrl=SqlController(formFields)
            fields=sqlCtrl.findData({"formKey":key},jsonDump=False)
            result["fields"]=fields
        jsonResult=json.dumps(missionResults)
        return HttpResponse(jsonResult)
    except Exception as e:
        return HttpResponse(str(e))
@csrf_exempt
def generateExamples(request):
    submitData=getJsonAjax(request,"submitData")
    #submitData=request.POST.get("submitData")
    #submitData=json.loads(submitData)
    formKey=submitData["formKey"]
    formUrl=submitData["formUrl"]
    equipmentUrl=submitData["equipmentUrl"]
    geneDatas=generateData(submitData)
    sqlCtrl=SqlController(testExamples)
    submitFields=submitData["fields"]
    #生成异常的用例
    for field in submitFields:
        exampleKey=createRandomChar()
        oneExample=({"relatedUserkey":"defaultuserkey",
                            "randomKey":exampleKey,
                            "formUrl":formUrl,
                            "equipmentUrl":equipmentUrl,
                            "formKey":formKey,
                             "ifSend":"no",
                             "expectResult":"异常"
                             })
        testExamples.objects.create(**oneExample)
        for data in geneDatas:
            sqlCtrl=SqlController(generateResult)
            insertGene=({
                         "relatedUserkey":"defaultuserkey",
                         "randomKey":createRandomChar(),
                         #"valueState":default,
                         #"defaultResult":submitFields[field]["default"],
                         "fieldName":data,
                         "exampleKey":exampleKey,
                         "formKey":formKey
                             })
            if geneDatas[data]["geneItem"]=="nothing":
                insertGene["valueState"]="default"
                insertGene["defaultResult"]=submitFields[data]["default"]
                insertGene["geneItem"]="nothing"
                generateResult.objects.create(**insertGene)
            else:
                if data == field:
                    insertGene["valueState"]="abnormal"
                    insertGene["abnormalResult"]=geneDatas[data]["abnormal"]
                    insertGene["normalResult"]=geneDatas[data]["normal"]
                else:
                    insertGene["valueState"]="normal"
                    insertGene["normalResult"]=geneDatas[data]["normal"]
                    insertGene["abnormalResult"]=geneDatas[data]["abnormal"]
                insertGene["geneItem"]=geneDatas[data]["geneItem"]
                print(insertGene)
                generateResult.objects.create(**insertGene)
    #生成正常的用例
    sqlCtrl=SqlController(testExamples)
    exampleKey=createRandomChar()
    sqlCtrl.insertData(({"relatedUserkey":"defaultuserkey",
                        "randomKey":exampleKey,
                        "formUrl":formUrl,
                        "equipmentUrl":equipmentUrl,
                        "formKey":formKey,
                        "ifSend":"no",
                        "expectResult":"正常"
                        }))
    for data in geneDatas:
        sqlCtrl=SqlController(generateResult)
        insertGene=({
                    "relatedUserkey":"defaultuserkey",
                    "randomKey":createRandomChar(),
                    "fieldName":data,
                    "exampleKey":exampleKey,
                    "formKey":formKey
                    })
        if geneDatas[data]["geneItem"]=="nothing":
            insertGene["valueState"]="default"
            insertGene["defaultResult"]=submitFields[data]["default"]
            insertGene["geneItem"]="nothing"
            sqlCtrl.insertData(insertGene)
        else:
            insertGene["valueState"]="normal"
            insertGene["normalResult"]=geneDatas[data]["normal"]
            insertGene["geneItem"]=geneDatas[data]["geneItem"]
            insertGene["abnormalResult"]=geneDatas[data]["abnormal"]
            sqlCtrl.insertData(insertGene)
    return HttpResponse("用例生成成功")
            
   
    
            
            
        
        
