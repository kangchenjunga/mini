from django.apps import AppConfig


class TestmissionManagerConfig(AppConfig):
    name = 'testmission_manager'
