from django.contrib import admin
from .models import TestMission
from .models import GenerateRecord
from .models import TestExamples
from .models import GenerateResult
admin.site.register(TestMission)
admin.site.register(GenerateRecord)
admin.site.register(GenerateResult)
admin.site.register(TestExamples)
# Register your models here.
