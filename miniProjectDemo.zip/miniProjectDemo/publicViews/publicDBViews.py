#coding=utf-8 
from django.shortcuts import render
from django.http import HttpResponse

from django.contrib.auth.decorators import login_required

from django.views.decorators.csrf import csrf_exempt

from controller.sqlController import SqlController
from controller.securitylib import createRandomChar

from equipment_manager.models import EquipmentInfo as equipmentInfo
from form_manager.models import Forms as forms
from form_manager.models import FormFields as formFields
from testmission_manager.models import TestMission as testMission
from testmission_manager.models import GenerateRecord as generateRecord
from testresult_manager.models import TestResult as testresult

import json

# Create your views here.
#@csrf_exempt
#SQL_CTRL=SqlController(euipmentInfo)
'''def index(request):
    try:
        sqlCtrl=SqlController(equipmentInfo)
        actionType=request.POST.get("actionType")
        submitData=request.POST.get("submitData")
        conditionData=request.POST.get("conditionData")
        result="数据有误"
        print(submitData)
        result=sqlCtrl.doChosenAction(actionType,submitData,conditionData)
        return HttpResponse(str(result))
    except Exception as e:
        return json.dumps({'state':'请求失败','detail':str(e)})'''
def getJsonAjax(request,want="submitData"):
    if request.method=="POST":
        postData=json.loads(request.body.decode())
        submitData=json.loads(postData[want])
        return submitData
'''增删改查等数据库操作的通用视图'''
@csrf_exempt
def addItem(request,controlModel,uniqueControl=False,keyGenerate=False,userRecord=False):
    try:
        sqlCtrl=SqlController(controlModel)
        submitData=getJsonAjax(request,"submitData")
        submitData["randomKey"]=createRandomChar()
        submitData["relatedUserkey"]="defaultuserkey"
        if uniqueControl:
            checkDic={}
            for i in uniqueControl:
                checkDic[i]=submitData[i]
            checkResult=sqlCtrl.findData(checkDic,jsonDump=False)
            if checkResult:
                return HttpResponse("已有相关记录，不允许重复")
            else:
                json.dumps(submitData)
        sqlCtrl.doChosenAction("insert",submitData)
        result=json.dumps({'state':'数据新增成功'})
        return HttpResponse(result)
    except Exception as e:
        return json.dumps({'state':'数据新增失败','detail':str(e)})
@csrf_exempt
def searchItem(request,controlModel):
    try:
        sqlCtrl=SqlController(controlModel)
        conditionData=getJsonAjax(request,"conditionData")
        result=sqlCtrl.doChosenAction("search",conditionData)
        return HttpResponse(result)
    except Exception as e:
        result=json.dumps({'state':'数据查询失败','detail':str(e)})
        return HttpResponse(result)
@csrf_exempt
def updateItem(request,controlModel):
    try:
        sqlCtrl=SqlController(controlModel)
        submitData=getJsonAjax(request,"submitData")
        conditionData=getJsonAjax(request,"conditionData")
        sqlCtrl.doChosenAction("update",submitData,conditionData)
        result=json.dumps({'state':'数据更新成功'})
        return HttpResponse(result)
    except Exception as e:
        result=json.dumps({'state':'数据更新失败','detail':str(e)})
        return HttpResponse(result)
@csrf_exempt
def deleteItem(request,controlModel,undoControl=False):
    try:
        sqlCtrl=SqlController(controlModel)
        conditionData={}
        if request.method=="POST":
            conditionData=getJsonAjax(request,"conditionData")
        if isinstance(conditionData,str):
            conditionData=json.loads(conditionData)    
        sqlCtrl.deleteData(conditionData)
        result=json.dumps({'state':'数据删除成功'})
        return HttpResponse(result)
    except Exception as e:
        result=json.dumps({'state':'数据删除失败','detail':str(e)})
        return HttpResponse(result)
            
        
