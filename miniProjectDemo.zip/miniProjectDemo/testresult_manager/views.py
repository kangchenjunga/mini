from django.shortcuts import render
import requests
import re
# Create your views here.
from testmission_manager.models import TestMission as testMission
from testmission_manager.models import GenerateRecord as generateRecord
from testmission_manager.models import TestExamples as testExamples
from testmission_manager.models import GenerateResult as generateResult
from equipment_manager.models import EquipmentInfo as equipmentInfo
from testresult_manager.models import TestResult as testResult
from form_manager.models import Forms as forms
from form_manager.models import FormFields as formFields

from django.http import HttpResponse

from django.views.decorators.csrf import csrf_exempt

from controller.sqlController import SqlController
from controller.formCrawler import FormCrawler
from controller.securitylib import createRandomChar
from controller.randGener import getRandomData
from publicViews.publicDBViews import getJsonAjax


import json
#生成请求向目标设备服务器提交
def makeRequest(equipmentUrl,formUrl,tourl,postDict,loginCondition=False):
    equipmentIp=re.findall(r"\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b", equipmentUrl)[0]
    tourl="https://"+str(equipmentIp)+tourl
    req=requests.session()
    crawler=FormCrawler(equipmentUrl)
    cookies=crawler.login({"user[password]":"nsfocus123","user[account]":"admin"},"login")
    cookieSettings=requests.cookies.RequestsCookieJar()
    for cookie in cookies:
        cookieSettings.set(cookie["name"],cookie["value"])
    req.cookies.update(cookieSettings)
    response=req.post(tourl,postDict,headers=crawler.headers,timeout=1,verify=False)
    result=response.content.decode("utf-8")
    print("设备返回："+result)
    return result   
@csrf_exempt
def doTest(request):
    posts=[]
    exampleRecord=[]
    submitData=getJsonAjax(request,"submitData")
    #submitData=request.POST.get("submitData")
    #submitData = json.loads(submitData)
    equipmentUrl=submitData["equipmentUrl"]
    formUrl=submitData["formUrl"]
    formKey=submitData["formKey"]
    toUrl=forms.objects.filter(randomKey=formKey)
    postUrl=toUrl[0].postto
    relatedExamples=testExamples.objects.filter(formKey=formKey)
    for example in relatedExamples:
        postDic={}
        exampleKey=example.randomKey
        sqlCtrl=SqlController(generateResult)
        geneFields=sqlCtrl.findData({"exampleKey":exampleKey},jsonDump=False)
        for field in geneFields:
            fieldName=field["fieldName"]
            valueState=field["valueState"]
            value=field[valueState+"Result"]
            postDic[fieldName]=value
        result=makeRequest(equipmentUrl,formUrl,postUrl,postDic)
        testExamples.objects.filter(randomKey=exampleKey).update(ifSend="yes",equipmentResponse=result)
    return HttpResponse("执行"+formUrl+"相关测试")
@csrf_exempt
def getTestResult(request):
    table={}
    tableHead=[]
    tableItems=[]
    submitData=getJsonAjax(request,"submitData")
    #submitData=request.POST.get("submitData")
    #submitData=json.loads(submitData)
    formKey=submitData["formKey"]
    relatedExamples=testExamples.objects.filter(formKey=formKey,ifSend="yes")
    sqlCtrl=SqlController(formFields)
    fields=sqlCtrl.findData({"formKey":formKey},jsonDump=False)
    for field in fields:
        tableHead.append(field["fieldName"])
    for example in relatedExamples:
        tableItem={"checkItem":"absolutelyNormal","expect":example.expectResult,"response":example.equipmentResponse}
        exampleKey=example.randomKey
        geneResults=generateResult.objects.filter(exampleKey=exampleKey)
        for geneResult in geneResults:
            tableItem[geneResult.fieldName]=({"state":geneResult.valueState})
            if geneResult.valueState=="abnormal":
                tableItem["checkItem"]==geneResult.geneItem
                tableItem[geneResult.fieldName]["value"]=geneResult.abnormalResult
            elif geneResult.valueState=="normal":
                tableItem[geneResult.fieldName]["value"] = geneResult.normalResult
            elif geneResult.valueState=="default":
                tableItem[geneResult.fieldName]["value"] = geneResult.defaultResult
        tableItems.append(tableItem)
    for item in tableItems:
        item["tableItem"]=[]
        item["tableItem"].append(item["checkItem"])
        for i in tableHead:
            if item[i]["value"] and item[i]["state"]:
                item["tableItem"].append(item[i]["value"]+"("+item[i]["state"]+")")
            elif item[i]["value"]:
                item["tableItem"].append(item[i]["value"])
            elif item[i]["state"]:
                item["tableItem"].append(item[i]["state"])
            #item["tableItem"].append(item[i]["state"])
        item["tableItem"].append(item["expect"])
        item["tableItem"].append(item["response"])
    tableHead.append("expectResult")
    tableHead.append("actualResult")
    tableDic={"tableHead":tableHead,"tableBody":tableItems}
    tableDic=json.dumps(tableDic)
    return HttpResponse(tableDic)
@csrf_exempt
def getUserChoice(request):
    submitData=getJsonAjax(request,"submitData")
    formKey=submitData["formKey"]
    fieldName=submitData["fieldName"]
    sqlCtrl=SqlController(generateResult)
    data=sqlCtrl.findData({"formKey":formKey,"fieldName":fieldName},jsonDump=False)[0]
    choiceDic=({"fieldName":data["fieldName"],
                "userChoice":data["geneItem"],
                "value":data[data[valueState+"Result"]]
                })
    return HttpResponse(choiceDic)
    
    
    
    
    
    
            
            
        
        
