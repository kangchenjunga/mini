from django.apps import AppConfig


class TestresultManagerConfig(AppConfig):
    name = 'testresult_manager'
