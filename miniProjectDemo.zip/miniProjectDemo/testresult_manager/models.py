from django.db import models

# Create your models here.
class TestResult(models.Model):
    relatedUserkey=models.CharField(max_length=20,blank=True)
    equipmentUrl=models.CharField(max_length=50)
    formUrl=models.CharField(max_length=50)
    relatedMission=models.IntegerField()
    time=models.CharField(max_length=50,blank=True)
    expectResult=models.CharField(max_length=50,blank=True)
    equipmentResponse=models.CharField(max_length=50,blank=True)
    ifExpect=models.CharField(max_length=50,blank=True)
    detail_log=models.CharField(max_length=255,blank=True)
    randomKey=models.CharField(max_length=50,blank=True)
