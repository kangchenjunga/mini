from django.contrib import admin
from .models import TestResult
admin.site.register(TestResult)
# Register your models here.
