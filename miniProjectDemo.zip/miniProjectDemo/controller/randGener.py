# -*- coding: utf-8 -*-

import random
import socket
import struct
import string
import os

def random_create_en_chars(normal_abnormal_flag):
    if normal_abnormal_flag:
        merge_str = []
        random_num = random.randint(0, 10)
        if random_num == 0:
            return '*'
        else:
            for i in range(0,random_num):
                en_chars = random.choice('abcdefghijklmnopqrstuvwxyz')
                merge_str.append(en_chars)
        return ''.join(merge_str)   
    else:                             #异常数据，包含特殊字符
        merge_str = []                   
        random_num = random.randint(0, 10)        
        for i in range(0,random_num):
            en_chars = random.choice('abcdefghijklmnopqrstuvwxyz')
            merge_str.append(en_chars)   
        special_char = random.choice('!@#$%&_<>/.')
        merge_str.append(special_char)
        return ''.join(merge_str)
    
#print random_create_en_chars(0)
        
def random_create_ch_chars(normal_abnormal_flag): 
    if normal_abnormal_flag:
        ch_chars = []
        ran_num = random.randint(0, 15)
        if ran_num == 0:
            return '*'
        else:
            for i in range(0,ran_num):
                ch_chars.append(unichr(random.randint(0x4e00,0x9fa5)))
            
            return ''.join(ch_chars)     
    else:
        random_num = random.randint(1, 4)    #表示[1,3)
       # random_num = 4
        if random_num == 1 :      #生成只有数字
            return str(random.randint(100,500))
        elif random_num == 2:     #只有英文
            ran_str = ''.join(random.sample(string.ascii_letters,4))
            return ran_str
        elif random_num == 3:     #只有中文
            first_name = ["王", "李", "张", "刘", "赵", "蒋", "孟", "陈", "徐", "杨", "沈", "马", "高", "殷", "上官", "钟", "常"]
            second_name = ["伟", "华", "建国", "洋", "刚", "万里", "爱民", "牧", "陆", "路", "昕", "鑫", "兵", "硕"]
            name = random.choice(first_name) + random.choice(second_name)    
            return name 
        elif  random_num == 4: #中英文数字的组合
            first_name = ["王", "李", "张", "刘", "赵", "蒋", "孟", "陈", "徐", "杨", "沈", "马", "高"]
            ch_chars = random.choice(first_name)
            ran_str = ''.join(random.sample(string.ascii_letters,4))
            ran_num = str(random.randint(100,500))
            return ch_chars+ran_str+ran_num
            
#print random_create_ch_chars(0);



def random_create_en_special_chars(normal_abnormal_flag):
    if normal_abnormal_flag:
        ran_num = random.randint(0, 15)
        if ran_num == 0:
            return '*'
        else:
            list = []
            FH = ('!','@','#','$','%','&','_',',') #特殊字符
            for i in range(1,ran_num):
                special_chars = random.choice(FH)
                list.append(special_chars)
            return ''.join(list)
    else:
        random_num = random.randint(1, 2)    #表示[1,3)
      #  random_num = 1
        if random_num == 1 :     #生成数字
            ran_str = ''.join(random.sample(string.digits,1))
            return ran_str
        elif random_num == 2:     #生成英文
            ran_str = ''.join(random.sample(string.ascii_letters,1))
            return ran_str

#print random_create_en_special_chars(0)          
        
        

def random_create_ch_special_chars(normal_abnormal_flag):
    if normal_abnormal_flag:
        ran_num = random.randint(0, 15)
        if ran_num == 0:
            
            return '*'
        else:
            list = []
            FH = ('!','@','#','$','%','&','_') #特殊字符
                   
            for i in range(1,ran_num):
                special_chars = random.choice(FH)
                list.append(special_chars)
            return ''.join(list)     
    else:
        random_num = random.randint(1, 2)    #表示[1,3)
        #  random_num = 1
        if random_num == 1 :     #生成数字
            ran_str = ''.join(random.sample(string.digits,1))
            return ran_str
        elif random_num == 2:     #生成英文
            ran_str = ''.join(random.sample(string.ascii_letters,1))
            return ran_str        
        

    
#print random_create_ch_special_chars(0)

def random_create_first_char(normal_abnormal_flag):     #随机生成首字母要求
    four_bit = []
    for i in range(0,4):
        four_bit.append(str(random.randint(0,1)))

    return ''.join(four_bit) 

#print random_create_first_char()
    


def random_create_port(normal_abnormal_flag):               #随机生成端口号
    if normal_abnormal_flag:
        ran_port = random.randint(1,65535)
        return ran_port
    else:
        random_num = random.randint(1, 3)    #表示[1,3)
      #  random_num = 1
        if random_num == 1 :      #生成小数
            decimal = random.uniform(1, 10)  
            return decimal
        elif random_num == 2 :     #生成负数
            ran_str = ''.join(random.sample(string.digits,1))
            merge_str = ['-',ran_str]
            return ''.join(merge_str)    
        elif random_num == 3:      #生成大于655356的数字
            ran_port = random.randint(65535,100000)
            return ran_port

#print random_create_port(0)

  
def random_create_port_group(normal_abnormal_flag):      #随机生成端口组合
    if normal_abnormal_flag:
        ran_port_group = []
        ran_port = random.randint(1,10000)
        ran_port_group.append(str(ran_port))
        ran_port1 = random.randint(ran_port, ran_port+10000)
        ran_port2 = random.randint(ran_port1, ran_port1+10000)
        merge1 = str(ran_port1) + '-' + str(ran_port2)
        ran_port_group.append(merge1)
        
        ran_port3 = random.randint(ran_port2, ran_port2+10000)
        ran_port4 = random.randint(ran_port3, ran_port3+10000)
        merge2 = str(ran_port3) + '-' + str(ran_port4)   
        ran_port_group.append(merge2)
        
        res = ','.join(ran_port_group)
        return res    
    else:
        random_num = random.randint(1, 3)    #表示[1,3)
         #  random_num = 1
        if random_num == 1 :      #生成小数
            decimal = random.uniform(1, 10)  
            return decimal
        elif random_num == 2 :     #生成负数
            ran_str = ''.join(random.sample(string.digits,1))
            merge_str = ['-',ran_str]
            return ''.join(merge_str)    
        elif random_num == 3:      #生成大于655356的数字
            ran_port = random.randint(65535,100000)
            return ran_port    


    
#print random_create_port_group()

def random_create_ipv4_pool(normal_abnormal_flag):          #随机生成ipv4池
    if normal_abnormal_flag:
        ipv4 = socket.inet_ntoa(struct.pack('>I',random.randint(1, 0xffffffff)))     #随机生成ipv4地址
        ipv4_int = lambda x:sum([256**j*int(i) for j,i in enumerate(x.split('.')[::-1])])    #将ipv4地址转换为整数
        start_num = ipv4_int(ipv4)
        
        ipv4_big = socket.inet_ntoa(struct.pack('>I',random.randint(start_num, 0xffffffff)))    #将从ipv4整数开始再次随机生成ip地址
     
        merge_res = [ipv4,'-',ipv4_big]
        return ''.join(merge_res)      
    else:
        random_num = random.randint(1, 3)    #表示[1,3)
       # random_num = 3
        if random_num == 1:             #生成字符串
            ran_str = ''.join(random.sample(string.ascii_letters,4))
            return ran_str
        elif random_num == 2:     #只有单个IP，不是IP组合
            ipv4 = socket.inet_ntoa(struct.pack('>I',random.randint(1, 0xffffffff)))     #随机生成ipv4地址
        elif random_num ==3 :       #IP池超出范围
            ipv4 = socket.inet_ntoa(struct.pack('>I',random.randint(1, 0xffffffff)))
            ip = []
            for i in range(1,4):
                ip.append(str(random.randint(0, 500)))
            ip.append(str(random.randint(256, 500)))
            ipv4_sec = '.'.join(ip)
            
            return ipv4+'-'+ipv4_sec
    
#print random_create_ipv4_pool(0)

def random_create_ipv4_groups(normal_abnormal_flag):        #随机生成ipv4组合
    if normal_abnormal_flag:
        single_ip = random.randint(1,3)
        double_ip = random.randint(1,3)
        ip = []
        for i in range(0,single_ip):
            ip.append(socket.inet_ntoa(struct.pack('>I',random.randint(1, 0xffffffff))))
        
        ipv4_int = lambda x:sum([256**j*int(i) for j,i in enumerate(x.split('.')[::-1])])    #将ipv4地址转换为整数
        start_num = ipv4_int(ip[i])
        
        for j in range(i,double_ip+i):
            ipv4_second = socket.inet_ntoa(struct.pack('>I',random.randint(start_num, 0xffffffff)))     #随机生成ipv4地址
            ipv4_int_second = lambda x:sum([256**j*int(i) for j,i in enumerate(x.split('.')[::-1])])    #将ipv4地址转换为整数
            start_num_second = ipv4_int(ipv4_second)
            ipv4_big_second = socket.inet_ntoa(struct.pack('>I',random.randint(start_num_second, 0xffffffff)))    #将从ipv4整数开始再次随机生成ip地址
            merge_res = [ipv4_second,'-',ipv4_big_second]
            ip.append(''.join(merge_res))
            
            start_num = start_num_second
        return ','.join(ip)        
    else:
        random_num = random.randint(1, 2)    #表示[1,3)
      #  random_num = 3     
        if random_num == 1:           #生成字符
            ran_str = ''.join(random.sample(string.ascii_letters,4))
            return ran_str        
        elif random_num == 2:    #IP超出范围
            
            ip = []
            for i in range(1,4):
                ip.append(str(random.randint(0, 500)))
            ip.append(str(random.randint(256, 500)))
            return '.'.join(ip)

#print random_create_ipv4_groups(0)
   
def random_create_ipv4_range(normal_abnormal_flag):         #随机生成ipv4网络
    if normal_abnormal_flag:
        ipv4 = socket.inet_ntoa(struct.pack('>I',random.randint(1, 0xffffffff)))    
        mask_bit =  random.randint(1,32)
        merge_res = [ipv4,'/',str(mask_bit)]
        return ''.join(merge_res)   
    else:
        random_num = random.randint(1, 2)    #表示[1,4)
     #  random_num = 2
        if random_num == 1:  #生成英文数字
            ran_str = ''.join(random.sample(string.ascii_letters+string.digits,8))
            return ran_str        
        elif random_num == 2:    #IP超出范围
          
            ip = []
            for i in range(1,4):
                ip.append(str(random.randint(0, 500)))
            ip.append(str(random.randint(256, 500)))
            return '.'.join(ip)        
        
#print random_create_ipv4_range(0)
    
def random_create_ipv4_node(normal_abnormal_flag):          #随机生成ipv4节点    
    if normal_abnormal_flag:
        ipv4 = socket.inet_ntoa(struct.pack('>I',random.randint(1, 0xffffffff)))
        return ipv4
    else:
        random_num = random.randint(1, 2)    #表示[1,4)
      #  random_num = 2
        if random_num == 1:  #生成英文数字
            ran_str = ''.join(random.sample(string.ascii_letters+string.digits,8))
            return ran_str        
        elif random_num == 2:    #IP超出范围
            
            ip = []
            for i in range(1,4):
                ip.append(str(random.randint(0, 500)))
            ip.append(str(random.randint(256, 500)))
            return '.'.join(ip)
#print random_create_ipv4_node(0)
    
def random_create_ipv6_range(normal_abnormal_flag):         #随机生成ipv6网络
    if normal_abnormal_flag:
        ipv6 = ':'.join('{0:x}'.format(random.randint(0,2**16-1)) for i in range(8))
        num_int =  random.randint(1, 64)
        merge_res = [ipv6,'/',str(num_int)]
        return ''.join(merge_res)    
    else:
        ch_chars = []
        ran_num = random.randint(1, 4)
        for i in range(0,ran_num):
            ch_chars.append(unichr(random.randint(0x4e00,0x9fa5)))   
        return ''.join(ch_chars)

#print random_create_ipv6_range(0)
    
def random_create_ipv6_node(normal_abnormal_flag):          #随机生成ipv6节点
    if normal_abnormal_flag:
        ipv6 = ':'.join('{0:x}'.format(random.randint(0,2**16-1)) for i in range(8))
        return ipv6
    else:
        ran_str = ''.join(random.sample(string.ascii_letters,4))
        return ran_str    
    

#print random_create_ipv6_node(0)

def random_create_mac(normal_abnormal_flag):                 #随机生成MAC地址  
    if normal_abnormal_flag:
        mac =[random.randint(0x00, 0xff),
              random.randint(0x00, 0xff),
              random.randint(0x00, 0xff),
              random.randint(0x00,0xff),
              random.randint(0x00, 0xff),
              random.randint(0x00, 0xff)]
        flag = random.randint(0, 1)
        if flag :
            return ':'.join(map(lambda x:"%02x" % x, mac))
        else:
            return '-'.join(map(lambda x:"%02x" % x, mac))
    else:
        random_num = random.randint(1, 2)    #表示[1,4)
       # random_num = 2
        if random_num == 1:       #生成字符串
            ran_str = ''.join(random.sample(string.ascii_letters,4))
            return ran_str
        elif random_num == 2:      #以十进制进行显示，合法的是以十六进制显示
            mac =[random.randint(0x00, 0xff),
                  random.randint(0x00, 0xff),
                  random.randint(0x00, 0xff),
                  random.randint(0x00,0xff),
                  random.randint(0x00, 0xff),
                  random.randint(0x00, 0xff)]            
            return ':'.join(map(lambda x:"%d" % x, mac))

#print random_create_mac(0)          

def random_create_time(normal_abnormal_flag):                 #随机生成时间
    if normal_abnormal_flag:
        num ={}  
        for i in [0,1,2,3]:
            if i==0:
                num[i] = random.randint(0, 2)  
            elif i==1:
                num[i] = random.randint(0, 3)  
            elif i==2:
                num[i] = random.randint(0, 5)  
            else :
                num[i] = random.randint(0, 9) 
                               
        res = "{}{}:{}{}".format(num[0],num[1],num[2],num[3])        
        return res
    else:
        random_num = random.randint(1, 3)    #表示[1,4)
        #random_num = 4
        if random_num == 1:  #生成英文数字
            ran_str = ''.join(random.sample(string.ascii_letters+string.digits,8))
            return ran_str
        elif random_num == 2:  #生成负数    
            ran_str = ''.join(random.sample(string.digits,1))
            merge_str = ['-',ran_str]
            return ''.join(merge_str)      
        elif random_num == 3:    #生成小数
            decimal = random.uniform(1, 10)  
            return decimal   
        elif random_num == 4:     #超过时间23:99
            num ={}  
            for i in [0,1,2,3]:        
                if i==0:
                    num[i] = random.randint(3, 9)  
                elif i==1:
                    num[i] = random.randint(4, 9)  
                elif i==2:
                    num[i] = random.randint(0, 5)  
                else :
                    num[i] = random.randint(0, 9) 
        
            res = "{}{}:{}{}".format(num[0],num[1],num[2],num[3])     
            return res 
           
#time = random_create_time(0)
#print (time)

def random_create_email(normal_abnormal_flag):   #随机生成邮件地址
    if normal_abnormal_flag:
        email_suffix = "@gmail.com,@yahoo.com,@msn.com,@hotmail.com,@aol.com,@ask.com,@live.com,@qq.com,@0355.net,@163.com,@163.net,@263.net,@3721.net,@yeah.net,@googlemail.com,@126.com,@sina.com,@sohu.com,@yahoo.com.cn".split(",");  
        email_len = len(email_suffix)
        random_num = random.randint(0, email_len-1)
        email_prefix = random_create_en_chars(1)
        email = [email_prefix,email_suffix[random_num]]
        return ''.join(email)
    else:
        random_num = random.randint(1, 2)
        if random_num == 1 :   #英文字母+数字
            ran_str = ''.join(random.sample(string.ascii_letters,4))
            ran_num = ''.join(random.sample(string.digits,3))
            res = ran_str + ran_num;
            return res 
        if random_num == 2:   #全是数字
            ran_num = ''.join(random.sample(string.digits,10))
            return ran_num
           
#print random_create_email(0)

def random_create_domin(normal_abnormal_flag):       #随机生成域名 
    if normal_abnormal_flag:
        random_num = random.randint(1, 20)
        ran_str = ''.join(random.sample(string.ascii_letters+string.digits+'-',random_num))
        merge_res = ['www',ran_str,'com']
        return '.'.join(merge_res)        
    else:
        random_num = random.randint(1, 3)    #表示[1,4)
      #  random_num = 3
        if random_num == 1:     #前面不是www
            num = random.randint(1, 200)
            ran_str = ''.join(random.sample(string.ascii_letters+string.digits+'-',random_num))
            merge_res = [str(num),ran_str,"aff"]
            return '.'.join(merge_res)
        elif random_num == 2:     #域名格式只有两项
            num = random.randint(1, 200)
            ran_str = ''.join(random.sample(string.ascii_letters+string.digits+'-',8))
            merge_res = [str(num),ran_str] 
            return '.'.join(merge_res)
        elif random_num == 3:    #产生汉字
            first_name = ["王", "李", "张", "刘", "赵", "蒋", "孟", "陈", "徐", "杨", "沈", "马", "高", "殷", "上官", "钟", "常"]
            second_name = ["伟", "华", "建国", "洋", "刚", "万里", "爱民", "牧", "陆", "路", "昕", "鑫", "兵", "硕", "志宏", "峰", "磊", "雷", "文","明浩", "光", "超", "军", "达"]
            name = random.choice(first_name) + random.choice(second_name)
            return name            
                           
#print random_create_domin(0)

def random_create_phone(normal_abnormal_flag):                      #随机生成手机号
    if normal_abnormal_flag:      
        second = [3,4,5,7,8][random.randint(0,4)]   #第二位数字
        
        third = {                                   #第三位数字
            3: random.randint(0, 9),
            4: [5,7,9][random.randint(0, 2)],
            5: [i for i in range(10) if i !=4][random.randint(0, 8)],
            7: [i for i in range(10) if i not in [4,9]][random.randint(0, 7)],
            8: random.randint(0, 9),
        }[second]
        
        suffix = random.randint(9999999, 100000000)
        
        return "1{}{}{}".format(second,third,suffix)
    else:
        phone_str = []
        merger_str = []
        random_num = random.randint(1, 3)    #表示[1,4)
      #  random_num = 3
        if random_num == 1:      #英文字母加上数字
            for i in range(1,6):
                x = random.choice('abcdefghijklmnopqrstuvwxyz')
                merger_str.append(x)       
            phone_str = ''.join(merger_str)
            phone_num= random.randint(999999, 10000000);
            
            phone = phone_str+str(phone_num)
            return phone
        elif random_num == 2:     #手机号码不等于11位
            phone = random.randint(1, 10000000000)
            return str(phone)
        elif random_num ==  3:     #汉字
            first_name = ["王", "李", "张", "刘", "赵", "蒋", "孟", "陈", "徐", "杨", "沈", "马", "高", "殷", "上官", "钟", "常"]
            second_name = ["伟", "华", "建国", "洋", "刚", "万里", "爱民", "牧", "陆", "路", "昕", "鑫", "兵", "硕", "志宏", "峰", "磊", "雷", "文","明浩", "光", "超", "军", "达"]
            name = random.choice(first_name) + random.choice(second_name)
            return name
      
#phone = random_create_phone(0)
#print(phone)    

def random_create_fixedline_phone(normal_abnormal_flag):         #随机生成固定电话
    
    if normal_abnormal_flag:        
        l_suffix = random.randint(9, 100)
        m_first = random.randint(2,8)
        m_two_eight = random.randint(999999, 10000000);
        r_suffix = random.randint(999, 10000)
        res = "0{}-{}{}-{}".format(l_suffix,m_first,m_two_eight,r_suffix)
        return res
    else:
        merger_str = []
        phone_str = []
        random_num = random.randint(1, 3)    #表示[1,4)
       # random_num = 2
        if random_num == 1:      #区号首位不为0
            l_suffix = random.randint(9, 100)
            m_first = random.randint(2,8);
            m_two_eight = random.randint(999999, 10000000);
            r_suffix = random.randint(999, 10000)
            res = "1{}-{}{}-{}".format(l_suffix,m_first,m_two_eight,r_suffix);   
            return res
        elif random_num == 2:     #英文字母加上数字
            for i in range(1,6):
                x = random.choice('abcdefghijklmnopqrstuvwxyz')
                merger_str.append(x)       
            phone_str = ''.join(merger_str)
            phone_num= random.randint(999999, 10000000);
            res = phone_str+'-'+str(phone_num)            
            return res
        elif random_num == 3:      #汉字
            first_name = ["王", "李", "张", "刘", "赵", "蒋", "孟", "陈", "徐", "杨", "沈", "马", "高", "殷", "上官", "钟", "常"]
            second_name = ["伟", "华", "建国", "洋", "刚", "万里", "爱民", "牧", "陆", "路", "昕", "鑫", "兵", "硕", "志宏", "峰", "磊", "雷", "文","明浩", "光", "超", "军", "达"]
            name = random.choice(first_name) + random.choice(second_name)
            return name            
         
#phone = random_create_fixedline_phone(0)
#print (phone)
def random_create_num(normal_abnormal_flag,min_value=1500,max_value=1700):
    #随机生成数字
    merger_str=[]
    if normal_abnormal_flag:  
      #  random_choice = random.randint(1, 4)
       # if random_choice == 1:              #随机生成数字
            random_num = random.randint(min_value, max_value)
            return str(random_num)              
    else :
        random_num = random.randint(1, 4)   
        if random_num == 1:         #随机生成英文字母+数字
            for i in range(1,6):
                random_char = random.choice('abcdefghijklmnopqrstuvwxyz')
                merger_str.append(random_str)  
            num_str = ''.join(merger_str)
            num = random_num = random.randint(0, 1000000000)
            return num_str+num
        elif random_num == 2:      #随机生成英文+数字+特殊符号
            ran_str = ''.join(random.sample(string.ascii_letters+string.digits+'!@#$%&_<>/.',8))
            return ran_str   
        elif random_num == 3:      #汉字
            first_name = ["王", "李", "张", "刘", "赵", "蒋", "孟", "陈", "徐", "杨", "沈", "马", "高", "殷", "上官", "钟", "常"]
            second_name = ["伟", "华", "建国", "洋", "刚", "万里", "爱民", "牧", "陆", "路", "昕", "鑫", "兵", "硕", "志宏", "峰", "磊", "雷", "文","明浩", "光", "超", "军", "达"]
            name = random.choice(first_name) + random.choice(second_name)
            return name          
         

def getRandomData(which):     
    data_info = {}
    data_info["en_chars"] = random_create_en_chars
    data_info["ch_chars"] = random_create_ch_chars
    data_info["en_special_chars"]=random_create_en_special_chars
    data_info["ch_special_chars"]=random_create_ch_special_chars
    data_info["first_char"]=random_create_first_char
    data_info["port"]=random_create_port
    data_info["port_group"]=random_create_port_group
    data_info["ipv4_pool"]=random_create_ipv4_pool
    data_info["ipv4_groups"]=random_create_ipv4_groups
    data_info["ipv4_range"]=random_create_ipv4_range
    data_info["ipv4_node"]=random_create_ipv4_node
    data_info["ipv6_range"]=random_create_ipv6_range
    data_info["ipv6_node"]=random_create_ipv6_node
    data_info["mac"]=random_create_mac
    data_info["time"]=random_create_time
    data_info["email"]=random_create_email
    data_info["phone"]=random_create_phone
    data_info["fixedline_phone"]=random_create_fixedline_phone
    data_info["random_num"]=random_create_num
    result=dict(normal=data_info[which](1),abnormal=data_info[which](0),geneItem=which)
    
    return result
 
    
    
    
