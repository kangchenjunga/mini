﻿#coding=utf-8
import json
import random
def createRandomChar(length=15):
    baseChar="abcdefg1h2i3jkl4mn5o6pq7rs8tuv9wx0yz"
    #baseChar+="ABCD9EF0GHIJKLMNOPQRSTUVWXYZ"
    returnChar=""
    for i in range(1,length):
        position=random.randint(0,35)
        returnChar+=baseChar[position]
    return returnChar   
def saltyMD5(password):
    pass

