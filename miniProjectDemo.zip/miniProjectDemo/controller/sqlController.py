﻿#coding=utf-8
from django.core import serializers
from django.forms.models import model_to_dict
import json
'''author:qianyulian@intra.focus.com'''
class SqlController(object):
    '''初始化，选择需要操控的model，增删改查结果以json格式响应'''
    def __init__(self,controlTarget):
        self.controlTarget=controlTarget
    '''增'''
    def insertData(self,dataDict):
        try:
            addData=self.controlTarget.objects.create(**dataDict)
            return json.dumps({"state":"新增成功"})
        except Exception as e:
            return json.dumps({"state":"新增失败","detail":str(e)})
    '''查'''
    def findData(self,conditionDict=False,jsonDump=True):
        try:
            allData=''
            if conditionDict:
                allData=self.controlTarget.objects.filter(**conditionDict)
            else:
                allData=self.controlTarget.objects.all()
            allData=self.querySetToJSON(allData)
            if jsonDump:
                return json.dumps(allData)
            else:
                return allData
        except Exception as e:
            return json.dumps({"state":'查询失败',"detail":str(e)})
        
    '''改'''
    def updateData(self,findCondition,updateDict):
        try:
            updateTarget=self.controlTarget.objects.filter(**findCondition)
            updated=updateTarget.update(**updateDict)
            return json.dumps({"state":"更新成功"})
        except Exception as e:
            return json.dumps({"state":"更新失败","detail":str(e)})
    '''删'''   
    def deleteData(self,deleteCondition):
        try:
            #print(str(type(deleteCondition)))
            deleteIt=(self.controlTarget.objects.filter(**deleteCondition)
                      .delete())
            print(serializer.serialize(deleteIt))
            returnDic=dict(state="删除成功")
            return json.dumps(returnDic)
        except Exception as e:
            returnDic=dict(state="删除失败")
            returnDic["detail"]=str(e)
            return json.dumps(returnDic)
    '''根据传入的action字符来判断该进行哪种操作,JSON字符串解析为字典'''
    def doChosenAction(self,action,dataDic=False,conditionDic=False):
        try:
            if isinstance(dataDic,str):
                dataDic=json.loads(dataDic)
            if isinstance(conditionDic,str):
                conditionDic=json.loads(conditionDic)
            if action == "insert":
                self.insertData(dataDic)
            elif action == "delete":
                self.deleteData(dataDic)
            elif action == "update" and conditionDic:
                self.updateData(conditionDic,dataDic)
            elif action=="search":
                responseDic=self.findData(dataDic)
                return responseDic
            else:
                return json.dumps({'state':'非法操作'})
            return json.dumps({'state':'success'})
        except Exception as e:
            return json.dumps({'state':'操作失败','detail':str(e)})
    '''将django orm的querySet类型转换为JSON可解析的类型'''
    def querySetToJSON(self,queryset):
        returnDatas=[]
        queryset=serializers.serialize("json",queryset)
        queryset=json.loads(queryset)
        if isinstance(queryset,list):
            for query in queryset:
                returnDatas.append(query["fields"])
        elif isinstance(queryset,str):
            returnDatas=queryset["fields"]
        else:
            returnDatas="非法类型"
        return returnDatas
