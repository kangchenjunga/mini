# coding:utf-8
import requests
from selenium import webdriver
from bs4 import BeautifulSoup
import time
import re
import json
import requests.cookies
from requests.cookies import RequestsCookieJar
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class FormCrawler(object):
    '''初始化，建立session,driver,设置设备登陆url和浏览器头部信息'''
    def __init__(self,loginUrl):
        self.session=requests.session()
        self.driver=webdriver.Chrome()
        self.loginUrl=loginUrl
        self.headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrom/65.0.3325.146 Safari/537.36'}
    '''登陆并返回cookies'''
    def login(self,loginInfo,loginButton):
        self.driver.get(self.loginUrl)
        for key in loginInfo:
            sender=(self.driver.find_element_by_name(key)
                    .send_keys(loginInfo[key]))
        self.driver.find_element_by_id(loginButton).click()
        time.sleep(1)
        cookies=self.driver.get_cookies()
        if cookies:
            #print("获取cookies成功")
            self.driver.quit()
            return cookies
        else:
            #print("获取cookies失败")
            return False
    '''添加cookies信息后获取表单数据'''
    def getFormData(self,formUrl,cookies):
        cookieSettings=requests.cookies.RequestsCookieJar()
        for cookie in cookies:
            cookieSettings.set(cookie["name"],cookie["value"])
        self.session.cookies.update(cookieSettings)
        response=self.session.get(formUrl,headers=self.headers,verify=False,timeout=1)
        html=response.content.decode("utf-8")
        soup=BeautifulSoup(html,"lxml")
        data=str(soup.form)
        pattern = re.compile(r'.*?(name)="(.*?)".*?(type)="(.*?)".*?(value)="(.*?)".*?')
        match_key = re.findall(pattern,data)
        pattern_post_url = re.compile(r'.*?(action)="(.*?)".*?')
        match_url = re.findall(pattern_post_url,data)
        infoDict={"formUrl":formUrl,"relatedEquipment":self.loginUrl,"postto":dict(match_url)["action"],"fields":[]}
        for x in match_key:
            item=dict(name=x[1],type=x[3],value=x[5])
            infoDict["fields"].append(item)
        return infoDict
'''使用步骤'''
'''crawler=FormCrawler("https://10.66.250.83/user/logout")#设备登陆url
cookies=crawler.login({"user[password]":"nsfocus123","user[account]":"admin"},"login")#两个参数，用户名和密码字典，登陆按钮的id
needData=crawler.getFormData("https://10.66.250.83/interface/edit?name=M",cookies)
print(needData)'''
'''slenium操作时无法通过ssl认证'''
'''执行测试任务时无法在字段集中获得具体字段'''
'''执行测试任务时无法正常使用正则表达式'''
'''执行测试任务时不能正常拼接出表单提交的完整url'''



        
            
            
        
        
        
        
        
    
    
    
        
    
        
        
        



