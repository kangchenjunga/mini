﻿#coding=utf-8
import json
'''author:qianyulian@intra.focus.com'''
class SqlController(object):
    '''初始化，选择需要操控的model，增删改查结果以json格式响应'''
    def __init__(self,controlTarget):
        self.controlTarget=controlTarget
    '''增'''
    def insertData(self,dataDict):
        try:
            dataObj=self.controlTarget(**dataDict)
            dataObj.save()
            return json.dumps({state:"新增成功"})
        except Exception as e:
            return json.dumps({state:"新增失败",detail:str(e)})
    '''查'''
    def findData(self,conditionDict):
        try:
            allData=self.controlTarget.objects.filter(**conditionDict)
            return json.dumps(allData)
        except Exception as e:
            return json.dumps({state:'查询失败',detail:str(e)})
        
    '''改'''
    def updateData(self,findCondition,updateDict):
        try:
            updateTarget=self.controlTarget.objects.filter(**findCondition)
            updated=updateTarget.update(**updateDict)
            return json.dumps({state:"更新成功"})
        except Exception as e:
            return json.dumps({state:"更新失败",detail:str(e)})
    '''删'''   
    def deleteData(self,deleteCondition):
        try:
            deleteIt=self.controllerTarget.filter(deleteCondition).delete()
            returnDic=dict(state="删除成功")
            return json.dumps(returnDic)
        except Exception as e:
            returnDic=dict(state="删除失败")
            returnDic["detail"]=str(e)
            return json.dumps(returnDic)
