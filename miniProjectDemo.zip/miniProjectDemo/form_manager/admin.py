from django.contrib import admin
from .models import Forms,FormFields
# Register your models here.
admin.site.register(Forms)
admin.site.register(FormFields)
