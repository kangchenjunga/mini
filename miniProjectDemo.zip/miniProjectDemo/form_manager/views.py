from django.shortcuts import render

# Create your views here.
from .models import Forms as forms
from .models import FormFields as formFields

from django.http import HttpResponse

from django.views.decorators.csrf import csrf_exempt

from equipment_manager.models import EquipmentInfo as equipmentInfo


from controller.sqlController import SqlController
from controller.securitylib import createRandomChar
from publicViews.publicDBViews import getJsonAjax
from controller.formCrawler import FormCrawler
'''pip install selemium'''
'''pip install beautifulsoup4'''
import json
'''新增Form数据，field分开存储'''
def addNewForm(submitData):
        formName=submitData["formName"]
        formUrl=submitData["formUrl"]
        postto=submitData["postto"]
        fields=submitData["fields"]
        equipmentUrl=submitData["relatedEquipment"]
        formRandom=createRandomChar()
        insertDict=({"formName":formName,
                     "formUrl":formUrl,
                     "postto":postto,
                     "relatedEquipment":equipmentUrl,
                     "relatedUserkey":"defaultuserkey",
                     "randomKey":formRandom
                     })
        forms.objects.create(**insertDict)
        #开始field存储
        relatedForms=(forms.objects
                    .filter(**insertDict))
        tail=len(relatedForms)-1
        relatedForm=relatedForms[tail].id
        for field in fields:
            formFields.objects.create(fieldName=field["name"],
                                        fieldType=field["type"],
                                        defaultValue=field["value"],
                                        formUrl=formUrl,
                                        formKey=formRandom,
                                        equipmentUrl=equipmentUrl,
                                        randomKey=createRandomChar(),
                                        relatedUserkey="defaultuserkey")
        submitData["formKey"]=formRandom
        return submitData 

@csrf_exempt
def addForm(request):
    try:
        submitData=getJsonAjax(request,"submitData")
        print(submitData)
        formName=submitData["formName"]
        formUrl=submitData["formUrl"]
        postto=submitData["postto"]
        fields=submitData["fields"]
        equipmentUrl=submitData["relatedEquipment"]
        formRandom=createRandomChar()
        insertDict=({"formName":formName,
                     "formUrl":formUrl,
                     "postto":postto,
                     "relatedEquipment":equipmentUrl,
                     "relatedUserkey":"defaultuserkey",
                     "randomKey":formRandom
                     })
        forms.objects.create(**insertDict)
        #开始field存储
        relatedForms=(forms.objects
                    .filter(**insertDict))
        tail=len(relatedForms)-1
        relatedForm=relatedForms[tail].id
        for field in fields:
            formFields.objects.create(fieldName=field["name"],
                                        fieldType=field["type"],
                                        defaultValue=field["value"],
                                        formUrl=formUrl,
                                        formKey=formRandom,
                                        equipmentUrl=equipmentUrl,
                                        randomKey=createRandomChar(),
                                        relatedUserkey="defaultuserkey")
        return HttpResponse("存储完成")
    except Exception as e:
        return HttpResponse(str(e))
@csrf_exempt
def crawlForm(request):#根据条件抓取form表单
    submitData=getJsonAjax(request,"submitData")
    #submitData=request.POST.get("submitData")
    #submitData=json.loads(submitData)
    equipmentUrl=submitData["relatedEquipment"]
    equipmentKey=submitData["equipmentKey"]
    formName=submitData["formName"]
    formUrl=submitData["formUrl"]
    equipment=equipmentInfo.objects.filter(loginUrl=equipmentUrl,randomKey=equipmentKey)[0]
    loginUrl=equipment.loginUrl
    username=equipment.userName
    password=equipment.password
    '''loginUrl="https://10.66.250.83/user/logout"
    password = "nsfocus123"
    username = "admin"'''
    crawler=FormCrawler(loginUrl)
    cookies=crawler.login({"user[password]":"nsfocus123","user[account]":"admin"},"login")
    needData=crawler.getFormData(formUrl,cookies)
    needData["formName"]=formName
    addNewForm(needData)
    return HttpResponse(json.dumps(needData))

        
'''根据一定条件(如所属设备）获取关联的form列表'''
@csrf_exempt
def getForms(request):
    try:
        returnList=[]
        sqlCtrl=SqlController(forms)
        conditionData=getJsonAjax(request,"conditionData")
        if isinstance(conditionData,str):
            conditionData=json.loads(conditionData)
        formResults=forms.objects.filter(**conditionData)
        for result in formResults:
            returnItem=({"formName":result.formName,
                         "formUrl":result.formUrl,
                         "postto":result.postto,
                         "relatedEquipment":result.relatedEquipment,
                         "randomKey":result.randomKey
                         })
            print(result.id)
            ID=result.id
            sqlCtrl=SqlController(formFields)
            fields=sqlCtrl.findData({"formKey":result.randomKey},jsonDump=False)
            returnItem["fields"]=[]
            for field in fields:
                filterField=(dict(fieldType=field["fieldType"],
                                  fieldName=field["fieldName"],
                                  defaultValue=field["defaultValue"]))
                returnItem["fields"].append(filterField)
            returnList.append(returnItem)
        jsonResult=json.dumps(returnList)
        return HttpResponse(jsonResult)
    except Exception as e:
        return HttpResponse(str(e))

    #equipmentInfo.objects.filter(randomKey="d06h084h05cvyd").update(loginUrl="https://10.66.250.83/user/logout",password="nsfocus123")
            
        
        
    
            
            
        
        
