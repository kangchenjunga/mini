from django.db import models

# Create your models here.
'''form的名称、要提交到哪个url，以及有哪些字段，各字段对应的生成规则'''
class Forms(models.Model):
    relatedUserkey=models.CharField(max_length=20,blank=True)
    formName=models.CharField(max_length=50)
    formUrl=models.CharField(max_length=50)
    postto=models.CharField(max_length=50)
    relatedEquipment=models.CharField(max_length=50)
    randomKey=models.CharField(max_length=50,blank=True)
    
'''fields的格式是json字符串，键是表单中可由用户自定义的字段，值是与数据生成有关的规则项目数组'''
class FormFields(models.Model):
    relatedUserkey=models.CharField(max_length=20,blank=True)
    formUrl=models.CharField(max_length=20,blank=True)
    formKey=models.CharField(max_length=20,blank=True)
    equipmentUrl=models.CharField(max_length=20,blank=True)
    fieldType=models.CharField(max_length=20)
    fieldName=models.CharField(max_length=20)
    defaultValue=models.CharField(max_length=20)
    randomKey=models.CharField(max_length=50,blank=True)
    
    

    
    
