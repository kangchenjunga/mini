from django.apps import AppConfig


class FormManagerConfig(AppConfig):
    name = 'form_manager'
