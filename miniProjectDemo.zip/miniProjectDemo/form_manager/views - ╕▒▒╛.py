from django.shortcuts import render

# Create your views here.
from .models import Forms as forms
from .models import FormFields as formFields

from django.http import HttpResponse

from django.views.decorators.csrf import csrf_exempt

from equipment_manager.models import EquipmentInfo as equipmentInfo

from controller.sqlController import SqlController

import json
'''新增Form数据，field分开存储'''
@csrf_exempt
def addForm(request):
    try:
        submitData=request.POST.get("submitData")
        submitData=json.loads(submitData)
        formName=submitData["formName"]
        formUrl=submitData["formUrl"]
        postto=submitData["postto"]
        fields=submitData["fields"]
        equipmentUrl=submitData["relatedEquipment"]
        insertDict=({"formName":formName,"formUrl":formUrl,
                         "postto":postto,"relatedEquipment":equipmentUrl})
        forms.objects.create(**insertDict)
        #开始field存储
        relatedForms=(forms.objects
                    .filter(**insertDict))
        tail=len(relatedForms)-1
        relatedForm=relatedForms[tail].id
        for field in fields:
            formFields.objects.create(fieldName=field["name"],
                                        fieldType=field["type"],
                                        defaultValue=field["value"],
                                        relatedForm=relatedForm)
        return HttpResponse("存储完成")
    except Exception as e:
        return HttpResponse(str(e))
'''根据一定条件(如所属设备）获取关联的form列表'''
@csrf_exempt
def getForms(request):
    try:
        returnList=[]
        sqlCtrl=SqlController(forms)
        conditionData=request.POST.get("conditionData")
        if isinstance(conditionData,str):
            conditionData=json.loads(conditionData)
        formResults=forms.objects.filter(**conditionData)
        for result in formResults:
            returnItem=({"formName":result.formName,
                         "formUrl":result.formUrl,
                         "postto":result.postto,
                         "relatedEquipment":result.relatedEquipment
                         })
            print(result.id)
            ID=result.id
            sqlCtrl=SqlController(formFields)
            fields=sqlCtrl.findData({"relatedForm":ID},jsonDump=False)
            returnItem["fields"]=[]
            for field in fields:
                returnItem["fields"].append(field)
            returnList.append(returnItem)
        jsonResult=json.dumps({"forms":returnList})
        return HttpResponse(jsonResult)
    except Exception as e:
        return HttpResponse(str(e))
            
            
            
        
        
    
            
            
        
        
