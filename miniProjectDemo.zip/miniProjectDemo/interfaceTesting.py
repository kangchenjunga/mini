﻿#coding=utf-8
import requests
import json
#使用requests来进行后端接口的测试
searchDevice="http://127.0.0.1:8000/searchDevice/"
addDevice="http://127.0.0.1:8000/addDevice/"
updateDevice="http://127.0.0.1:8000/updateDevice/"
deleteDevice="http://127.0.0.1:8000/deleteDevice/"

rigister="http://127.0.0.1:8000/regist/"
login="http://127.0.0.1:8000/login/"

addform="http://127.0.0.1:8000/addForm/"
getform="http://127.0.0.1:8000/getForms/"

addMission="http://127.0.0.1:8000/addMission/"
getMission="http://127.0.0.1:8000/getMission/"

exampleGenerate="http://127.0.0.1:8000/generateExample/"

device_insert={
    'submitData':'{"equipmentType":"sas","equipmentName":"sas-1014","loginUrl":"https://112.21.38.28/login","userName":"admin","password":"12345678"}'
    }
device_search={
    
    }
device_filter_search={
    "conditionData":'{"relatedUserkey":"defaultuserkey"}'
    }
device_update={
    "submitData":'{"equipmentName":"sas-1013"}',
    "conditionData":'{"equipmentName":"sas-1012"}'
    }
device_delete={
    "conditionData":'{"equipmentName":"sas-1014"}'
    }
regist_test={
    "email":"12345@123.com",
    "password":"12345678",
    "repassword":"12345678"
    }
login_test={
    "email":"12345@123.com",
    "password":"12345678"
    }
add_form2={
    'submitData':('{"formName":"networkPost2",'+
                  '"formUrl":"https://112.21.38.28/cat/",'+
                  '"postto":"/storage/",'+
                  '"relatedEquipment":"https://112.21.38.28/login/",'+
                  '"fields":[{"name":"interface[name]","type":"text","value":"M"},{"name":"interface[zone]","type":"text","value":"10.245.34.199"},{"name":"interface[mask]","type":"text","value":"255.255.0.0"},{"name":"interface[gateway]","type":"text","value":"M"},{"name":"interface[isdefault]","type":"radio","value":"true"},{"name":"interface[isdefault]","type":"radio","value":"false"},{"name":"interface[linkmode]","type":"text","value":"1500"}]'+
                  '}')
                
    }
get_form={
    'conditionData':'{"relatedUserkey":"defaultuserkey"}'
    }
add_mission={
    'submitData':'{"missionName":"任务1","equipmentUrl":"https://112.21.38.28/login/","formUrl":"https://112.21.38.28/cat/","missionStatus":"beforeTest","comment":"没有备注"}'
    }
get_mission={
    'conditionData':'{"relatedUserkey":"defaultuserkey"}'
    }
example_generate={
    'submitData':('{"formKey":"o7t2s2w7aalu6e","formUrl":"https://112.21.38.28/cat/","equipmentUrl":"https://112.21.38.28/login/","fields":"{"email":{"item":"email"},"username":{"item":"en_chars"},"sourceIp":{"item":"ipv4_pool"},"targetIp":{"item":"ipv4_pool"},"interface":{"item":"port"},"createTime":{"item":"time"},"ifSure":{"item":"nothing","default":False}}"}')
    }
#submitData=json.loads(add_form2["submitData"])
#print(submitData["formName"])
#result1=requests.post(login,login_test).text
#print(result1)
#result2=requests.post(searchDevice).text
#print(result2)
#result2=requests.get(login).text
#print(result2)
#result3=requests.post(addform,add_form2).text
#print(result3)

#result4=requests.post(getform,get_form).text
#print(result4)
'''测设备添加'''
#result1=requests.post(addDevice,device_insert).text
#print(result1)
'''测设备更新'''
#result2=requests.post(updateDevice,device_update).text
#print(result2)
'''测设备删除'''
#result3=requests.post(deleteDevice,device_delete).text
#print(result3)
'''测设备查询'''
#result7=requests.post(searchDevice,device_filter_search).text
#print(result7)
'''测注册'''
#result4=requests.post(rigister,regist_test).text
#print(result4)
'''测表单添加'''
#result5=requests.post(addform,add_form2).text
#print(result5)
'''测表单获取'''
#result6=requests.post(getform,get_form).text
#print(result6)
'''测任务添加'''
#result7=requests.post(addMission,add_mission).text
#print(result7)
'''测任务获取'''
#result8=requests.post(getMission,get_mission).text
#print(result8)
'''测测试用例生成'''


