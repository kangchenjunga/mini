from django.apps import AppConfig


class AccountManagerConfig(AppConfig):
    name = 'account_manager'
