from django.contrib import admin
from .models import userAccount

admin.site.register(userAccount)

# Register your models here.
