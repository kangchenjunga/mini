from django.shortcuts import render
from django import forms

from django.contrib import auth
from django.contrib.auth import logout
from django.contrib.auth import authenticate,login
from django.contrib.auth.models import User

from django.http import HttpResponse

from account_manager.models import userAccount as user

from django.views.decorators.csrf import csrf_exempt

from controller.sqlController import SqlController
from controller.securitylib import createRandomChar
from publicViews.publicDBViews import getJsonAjax
'''注册，匹配用户输入的密码并确认邮箱是否已经被注册'''
@csrf_exempt
def regist(request):
    if request.method=="POST":
        submitData=getJsonAjax(request,"submitData")
        email=submitData["email"]
        password=submitData["password"]
        repassword=submitData["repassword"]
        if password != repassword:
            return httpRequest("两次密码不匹配")
        if user.objects.filter(username=email):
            return HttpResponse('此邮箱已被注册')
        else:
            u=(user.objects.create_user(username=email,
                    email=email,password=password,userkey=createRandomChar()))
            return HttpResponse("注册成功")
    else:
        return HttpResponse("非法请求")
        
        
        
# Create your views here.
@csrf_exempt
def login(request):
    if request.method == 'POST':
        submitData=getJsonAjax(request,"submitData")
        email=submitData["email"]
        password=submitData["password"]
        user=authenticate(username=email,password=password)
        if user:
            auth.login(request,user)
            if request.user.is_authenticated:
                return HttpResponse("登陆成功")
            else:
                return HttpResponse("登陆失败")
        else:
            return HttpResponse("用户名或密码错误")
    else:
        if request.user.is_authenticated:
            return HttpResponse("欢迎你"+request.user.username)
        else:
            return HttpResponse("请登陆")
        
@csrf_exempt
def logoutView(request):
    try:
        logout(request)
        return HttpResponse("已登出")
    except Exception as e:
        return HttpResponse(str(e))
