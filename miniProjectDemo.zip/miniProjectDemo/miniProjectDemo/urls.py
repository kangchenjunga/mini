"""miniProjectDemo URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from publicViews import publicDBViews as public_db_views

from form_manager import views as form_views
from equipment_manager import views as equipment_views
from testmission_manager import views as testmission_views
from testresult_manager import views as testresult_views
from account_manager import views as account_views

from equipment_manager.models import EquipmentInfo as equipmentInfo
from form_manager.models import Forms as forms
from form_manager.models import FormFields as formFields
from testmission_manager.models import TestMission as testMission
from testmission_manager.models import GenerateRecord as generateRecord
from testresult_manager.models import TestResult as testResult

from django.views.generic.base import TemplateView

urlpatterns = [
    path(r'',TemplateView.as_view(template_name="index.html")),
    path('admin/', admin.site.urls),

    path('regist/',account_views.regist),
    path('login/',account_views.login),
    path('logout/',account_views.logoutView),
    
    path('addDevice/',public_db_views.addItem,{"controlModel":equipmentInfo}),
    path('searchDevice/',public_db_views.searchItem,{"controlModel":equipmentInfo}),
    path('updateDevice/',public_db_views.updateItem,{"controlModel":equipmentInfo}),
    path('deleteDevice/',public_db_views.deleteItem,{"controlModel":equipmentInfo}),

    path('addForm/',form_views.addForm),
    path('getForms/',form_views.getForms),
    path('deleteForm/',public_db_views.deleteItem,{"controlModel":forms}),
    path('updateForm/',public_db_views.updateItem,{"controlModel":forms}),

    path('addMission/',testmission_views.addMission),
    path('getMission/',testmission_views.getMissions),
    path('deleteMission/',public_db_views.deleteItem,{"controlModel":testMission}),
    path('updateMission/',public_db_views.updateItem,{"controlModel":testMission}),

    path('generateExample/',testmission_views.generateExamples),
    #这三个接口需要测
    path('doTest/',testresult_views.doTest),
    path('testResult/',testresult_views.getTestResult),
    path('getUserChoice/',testresult_views.getUserChoice),
    path('crawlForm/',form_views.crawlForm)
   
         
    
]
