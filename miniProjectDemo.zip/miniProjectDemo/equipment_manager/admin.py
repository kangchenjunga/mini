from django.contrib import admin
from .models import EquipmentInfo
# Register your models here.
admin.site.register(EquipmentInfo)
