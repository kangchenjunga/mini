from django.apps import AppConfig


class EquipmentManagerConfig(AppConfig):
    name = 'equipment_manager'
