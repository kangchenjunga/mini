#coding=utf-8
from django.db import models

# Create your models here.
'''设备的信息，包括设备名,登陆链接，用户名，密码四项'''
class EquipmentInfo(models.Model):
    relatedUserkey=models.CharField(max_length=20,blank=True)
    equipmentName=models.CharField(max_length=100)
    equipmentType=models.CharField(max_length=100,blank=True)
    loginUrl=models.CharField(max_length=100)
    userName=models.CharField(max_length=100)
    password=models.CharField(max_length=100)
    comment=models.CharField(max_length=100,blank=True)
    randomKey=models.CharField(max_length=50,blank=True)
    
